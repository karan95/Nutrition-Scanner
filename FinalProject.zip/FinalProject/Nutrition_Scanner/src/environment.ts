export const environment = {
    firebaseConfig: {
        apiKey: "",
        authDomain: "localhost",
        databaseURL: "https://nutrition-scanner.firebaseio.com/",
        projectId: "nutrition-scanner",
        storageBucket: "staging.nutrition-scanner.appspot.com",
        messagingSenderId: ""
    },
    googleCloudVisionAPIKey: "AIzaSyCSbbUcr4Ri1jeCeYKNvLnTsqI5gPFkxRM"
};

// AIzaSyB5wWTgz2hODJMm0JNQCicRZ9JzyEJDpbk