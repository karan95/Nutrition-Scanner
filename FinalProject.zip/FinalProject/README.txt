Internet and Web Systems Directed Study Final Project Submission:

Objective:
    I tried to learn much of the technologies from the Internet and Web Systems directed study subject.
    I received a very good response and idea from professor to develop an exceptional project.
    Initially, I wasn't sure that what I am going to develop but at day by day I got idea and references to develop something.
    As a part of the subject, I have done following things.

Project: Nutrition Scanner
    Goal: I decided to develop an application which can help users on daily basis. 
    After consultation with the professor, I decided to develop the food scanner application get food nutrients.
    Nutrition Scanner application provides a user the ability to scan food product and get results of nutritionists.​

    Future Work: In my project report, I have specified future work of this project.

Research Papers:
    Paper 1: Comparison of Javascript Frameworks for Single Page Web Application
            After detailed Proof of concept, I tried to write this paper. I have referred the number of article and website for getting the source. 
            It's wide are but I tried to cover as much point I can.
    
    Paper 2: Also for this paper, I have reviewed number of the research paper, articles website. 
            Much of the source is from the internet due to the complexity of research area. Also, the time was constraint so I was able to do this much only.
            Because I devoted much of my time doing the project.
            
BibTAX: I have referred mostly all this research paper for my project and research related work. I found much of the IWS related research paper on ACM digital library so almost all BibTeX are from ACM.

